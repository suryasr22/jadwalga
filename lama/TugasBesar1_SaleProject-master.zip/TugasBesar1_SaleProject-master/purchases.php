<!doctype html>
	<?php
		include "get_username.php";
	?>
<html>
	<head>
	<title>SaleProject</title>
	<script src = "functions.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	<body>
	<h2><font color='maroon'>Sale</font><font color='#3d87ff'>Project</h2></font>
	<div class="account">
	Hi, <?php echo $username?>!
	<br><a class="logout" href="index.php">logout</a>
	</div>

	<ul>
		<li><a href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li><a href="your_products.php?active_id=<?php echo $id; ?>">Your Products</a></li>
		<li><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li><a href="sales.php?active_id=<?php echo $id; ?>">Sales</a></li>
		<li><a class="active">Purchases</a></li>
	</ul>
	<h3>Here are your purchases</h3>
	<hr>
	<br>

	<?php
		$query="select product.image, purchase.date_now, purchase.time_now, product.name, purchase.total_price, purchase.quantity, purchase.price, users.username, purchase.consignee, purchase.address, purchase.postal_code, purchase.phone_number from product,purchase,users where product.id_product=purchase.id_product and purchase.id_seller=users.id_user and id_buyer='$id'";
		$perintah=mysql_query($query);
				
		if(mysql_num_rows($perintah) > 0){
			while ($data=mysql_fetch_array($perintah)){
					echo $data['date_now'] . "<br>";
					echo "at " . $data['time_now'] . "<hr>";
				?>
				<div class="product">
					<img src="uploads/<?php echo $data['image']; ?>" width="100" height="100">

					<div class="pdetails">
						<div class="bold"><?php echo $data['name'] . "<br>";?></div>
						<?php echo "IDR " . $data['total_price'] . "<br>";?>
						<?php echo $data['quantity'] . " pcs<br>";?>
						<div class="price"><?php echo "@ " . $data['price'] . "<br>"; ?></div>
						<?php echo "<br>bought from " . $data['username'] . "<br>"; ?>
					</div>

					<div class="udetails">
						<?php
							echo "Delivery to " . $data['consignee'] . "<br>";
							echo $data['address'] . "<br>";
							echo $data['postal_code'] . "<br>";
							echo $data['phone_number'] . "<br>";
						?>
					</div>
				</div>
				<hr>
				<br><br>
				<?php
			}
		}
		else{
			echo "You haven't bought any product yet!";
		}
		
?>

<br></br>
</table>
</form>
</body>