<!doctype html>
	<?php
		include "get_username.php";
	?>
<html>
	<head>
	<title>SaleProject</title>
	</head>
	<script src = "functions.js"></script>

	<body>
	<h2>SaleProject</h2>
	Hi, <?php echo $username?>!
	<br><a href="index.php">logout</a>

	<ul class="sub">
		<li class="sub"><a class="active" href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li class="sub"><a href="">Your Products</a></li>
		<li class="sub"><a href="">Add Product</a></li>
		<li class="sub"><a href="">Sales</a></li>
		<li class="sub"><a href="">Purchases</a></li>
	</ul>

	<h3>Please add your product here</h3>
	<hr>

	<form name="product" action="proses_add_product.php?active_id=<?php echo $id; ?>" onblur="validateProduct();" onchange="validateProduct();" method="post" enctype="multipart/form-data">
	Name<br>
	<input type="text" name="name" onchange="validatePName();"><br><p id="name"></p>
	Description (max 200 chars)<br>
	<textarea name="desc" onchange="validateDesc();"></textarea><br><p id="desc"></p>
	Price (IDR)<br>
	<input type="text" name="price" onchange="validatePrice();"><br><p id="price"></p>
	Photo<br>
	<input id="image" type="file" name="image" onchange="validate_fileupload();"><br><br><p id="image"></p>
	<input id="submit" type="submit" value="ADD" disabled>
	<input type="button" value="CANCEL">
	</form>

	</body>

</html>