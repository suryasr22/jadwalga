<?php
	include "koneksi.php";

	$id_product = $_POST["id_product"];
	$id_user = $_POST["id_user"];

	$query = mysql_query("select * from likes where id_product='$id_product' and id_liker='$id_user'");
	$rows = mysql_num_rows($query);

	if($rows==0){
		echo "LIKE";
	}
	else{
		echo "LIKED";
	}
?>