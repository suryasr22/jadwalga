<?php
include "koneksi.php";

$id_product = $_GET['id_product'];
$id_user = $_GET['active_id'];

$delete = mysql_query("delete from product where id_product='$id_product' and id_user='$id_user'");
header ("location:your_products.php?active_id=" . $id_user);

?>