<?php
	include "koneksi.php";
	$id = $_GET["active_id"];
	$query = mysql_query("select * from users where id_user='$id'");
	$row = mysql_fetch_array($query);
	$username = $row["username"];
?>