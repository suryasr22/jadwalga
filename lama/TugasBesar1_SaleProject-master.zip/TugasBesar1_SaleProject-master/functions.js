function validate(x,y){
	if(x==""||x==null){
		document.getElementById(y).innerHTML = "Kolom ini harus diisi";
		return false;
	}
	else{
		document.getElementById(y).innerHTML = "";
		return true;
	}
}

function validateNum(x,y){
	if(isNaN(x)||x==""||x==null){
		document.getElementById(y).innerHTML = "Input tidak valid";
		return false;
	}
	else{
		document.getElementById(y).innerHTML = "";
		return true;
	}
}

function validateFName(){
	var x = document.forms["register"]["fullname"].value;
	var y = "fullname";
	validate(x,y);
}

function validateUName(){
	var x = document.forms["register"]["username"].value;
	var y = "username";
	validate(x,y);
}

function validateEmail(){
    var x = document.forms["register"]["email"].value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        document.getElementById("email").innerHTML = "Email tidak valid";
        return false;
    }
    else{
		document.getElementById("email").innerHTML = "";
		return true;
	}
}

function validatePassword(){
	var x = document.forms["register"]["password"].value;
	var y = "password";
	validate(x,y);
}

function confirmPassword(){
	var x = document.forms["register"]["password"].value;
	var y = document.forms["register"]["confirmpassword"].value;
	if(x!=y){
		document.getElementById("confirmpassword").innerHTML = "Password harus sama";
		return false;
	}
	else{
		document.getElementById("confirmpassword").innerHTML = "";
		return true;
	}
}

function validateAddress(){
	var x = document.forms["register"]["address"].value;
	var y = "address";
	validate(x,y);
}

function validatePostal(){
	var x = document.forms["register"]["postal_code"].value;
	var y = "postal_code";
	validate(x,y);
}

function validatePhone(){
	var x = document.forms["register"]["phone_number"].value;
	var y = "phone_number";
	validate(x,y);
}

function validateForm(){
	var x = document.forms["register"];
	var i;
	var count=0;
	var a = document.forms["register"]["email"].value;
	var b = document.forms["register"]["confirmpassword"].value;
	for(i=0; i<x.length; i++){
		if(x.elements[i].value == "" || x.elements[i].value==null){
			count++;
		}
	}
	if(a != ""||a != null||a != undefined){
		a = !validateEmail();
	}
	if(b != ""||b != null||b != undefined){
		b = !confirmPassword();
	}
	if(count+a+b==0){
		document.getElementById("submit").disabled = false;
		return true;
	}
	else{
		document.getElementById("submit").disabled = true;
		return false;
	}
}

function validatePName(){
	var x = document.forms["product"]["name"].value;
	var y = "name";
	validate(x,y);
}

function validateDesc(){
	var x = document.forms["product"]["desc"].value;
	var y = "desc";
	validate(x,y);
}

function validatePrice(){
	var x = document.forms["product"]["price"].value;
	var y = "price";
	validateNum(x,y);
}

function validate_fileupload()
{
    var x = document.forms["product"]["image"].value;
    var allowed_extensions = new Array("jpg","png","gif");
    var file_extension = x.split('.').pop();
    for(var i = 0; i <= allowed_extensions.length; i++)
    {
        if(allowed_extensions[i]==file_extension)
        {
            document.getElementById("image").innerHTML = "";
            return true;
        }
    }
    document.getElementById("image").innerHTML = "Format file salah";
    return false;
}

function validateProduct(){
	var x = document.forms["product"];
	var i;
	var count=0;
	var a = document.forms["product"]["price"].value;
	var b = !validate_fileupload();
	for(i=0; i<x.length; i++){
		if(x.elements[i].value == "" || x.elements[i].value==null){
			count++;
		}
	}
	if(a != ""||a != null||a != undefined){
		a = !validatePrice();
	}
	if((count+a+b-1)==0){
		document.getElementById("submit").disabled = false;
		return true;
	}
	else{
		document.getElementById("submit").disabled = true;
		return false;
	}
}

function validateProduct1(){
	var x = document.forms["product"];
	var i;
	var count=0;
	var a = document.forms["product"]["price"].value;
	for(i=0; i<x.length; i++){
		if(x.elements[i].value == "" || x.elements[i].value==null){
			count++;
		}
	}
	if(a != ""||a != null||a != undefined){
		a = !validatePrice();
	}
	if((count+a-2)==0){
		document.getElementById("submit").disabled = false;
		return true;
	}
	else{
		document.getElementById("submit").disabled = true;
		return false;
	}
}

function addLike(id_product){
	var xhttp = new XMLHttpRequest();
	var x = document.getElementById("like"+id_product);
	var ele = document.getElementById(id_product);
	if(ele.value == "LIKED"){
		state = "0";
	}
	else{
		state = "1";
	}
	xhttp.onreadystatechange = function(){
		if (this.readyState == 4 && this.status == 200){
			x.innerHTML = this.responseText;
		}
	};
	xhttp.open("POST", "ref_like.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send("id_product="+id_product+"&state="+state);
}

function like(id_product, id_user, target){
	var xhttp = new XMLHttpRequest();
	var ele = document.getElementById(id_product);
	var state;
	if(ele.value == "LIKED"){
		state = 0;
	}
	else{
		state = 1;
	}
	xhttp.onreadystatechange = function(){
		if (this.readyState == 4 && this.status == 200){
			ele.value = this.responseText;
			if(ele.value == "LIKED"){
				ele.className = "liked";
			}
			else{
				ele.className = "like";
			}
		}
	};
	xhttp.open("POST", target, true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send("id_product="+id_product+"&id_user="+id_user+"&state="+state);
}

function validateQty(){
	var x = document.forms["confirm"]["quantity"].value;
	if(isNaN(x)||x==""||x==null){
		return false;
	}
	else{
		return true;
	}
}

function countTotal(qty,price){
	var total = qty*price;
	document.getElementById("total").innerHTML= "IDR "+total;
}

function validateCons(){
	var x = document.forms["confirm"]["consignee"].value;
	var y = "consignee";
	validate(x,y);
}

function validateAddr(){
	var x = document.forms["confirm"]["address"].value;
	var y = "address";
	validate(x,y);
}

function validatePostC(){
	var x = document.forms["confirm"]["postal_code"].value;
	var y = "postal_code";
	validate(x,y);
}

function validatePhn(){
	var x = document.forms["confirm"]["phone_number"].value;
	var y = "phone_number";
	validate(x,y);
}

function validateDigits(x,y,z){
	if(x.length!=z || isNaN(x)||x==""||x==null){
		document.getElementById(y).innerHTML = "Credit Card Tidak Valid";
		return false;
	}
	else{
		document.getElementById(y).innerHTML = "";
		return true;
	}
}

function validate16(){
	var x = document.forms["confirm"]["cc_number"].value;
	var y = "cc_number";
	var z = 16;
	validateDigits(x,y,z);
}

function validate3(){
	var x = document.forms["confirm"]["cc_verif"].value;
	var y = "cc_verif";
	var z = 3;
	validateDigits(x,y,z);
}

function validatePurchase(){
	var x = document.forms["confirm"];
	var i;
	var count=0;
	var a = document.forms["confirm"]["cc_number"].value;
	var b = document.forms["confirm"]["cc_verif"].value;
	var c = document.forms["confirm"]["quantity"].value;
	for(i=0; i<x.length; i++){
		if(x.elements[i].value == "" || x.elements[i].value==null){
			count++;
		}
	}
	if(a != ""||a != null||a != undefined){
		a = !validate16();
	}
	if(b != ""||b != null||b != undefined){
		b = !validate3();
	}
	if(c != ""||c != null||c != undefined){
		c = !validateQty();
	}
	if((count+a+b+c-2)==0){
		document.getElementById("submit").disabled = false;
		return true;
	}
	else{
		document.getElementById("submit").disabled = true;
		return false;
	}
}