<?php
	include "koneksi.php";

	$id_product = $_POST["id_product"];
	$id_user = $_POST["id_user"];
	$state = $_POST["state"];

	if($state==1){
		mysql_query("insert into likes (id_product,id_liker) values ('$id_product','$id_user')");
		mysql_query("update product set likes=likes+1 where id_product='$id_product'");
		echo "LIKED";
	}
	else{
		mysql_query("delete from likes where id_product='$id_product' and id_liker='$id_user'");
		mysql_query("update product set likes=likes-1 where id_product='$id_product'");
		echo "LIKE";
	}
	
?>