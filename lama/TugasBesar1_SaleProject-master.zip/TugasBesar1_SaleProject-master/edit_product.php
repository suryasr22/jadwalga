<!doctype html>
	<?php
		include "get_username.php";

		$id_product = $_GET['id_product'];
		$id_user = $_GET['active_id'];

		$query = "select * from product where id_product='$id_product' and id_user='$id_user'";
		$perintah = mysql_query($query);
		$data=mysql_fetch_array($perintah);
	?>
<html>
	<head>
	<title>SaleProject</title>
	</head>
	<script src = "functions.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">

	<body>
	<h2><font color='maroon'>Sale</font><font color='blue'>Project</h2></font>
	<div class="account">
	Hi, <?php echo $username?>!
	<br><a class="logout" href="index.php">logout</a>
	</div>

	<ul >
		<li><a href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li><a href="your_products.php?active_id=<?php echo $id; ?>">Your Products</a></li>
		<li><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li><a href="">Sales</a></li>
		<li><a href="">Purchases</a></li>
	</ul>

	<h3>Please add your product here</h3>
	<hr>

	<form name="product" action="proses_edit_product.php?active_id=<?php echo $id; ?>&id_product=<?php echo $id_product; ?>" onblur="validateProduct1();" onchange="validateProduct1();" method="post" enctype="multipart/form-data">
	Name<br>
	<input class="form" type="text" name="name" onchange="validatePName();" value="<?php echo $data["name"];?>"><br><p id="name"></p>
	Description (max 200 chars)<br>
	<textarea class="form" name="desc" onchange="validateDesc();"><?php echo $data["description"];?></textarea><br><p id="desc"></p>
	Price (IDR)<br>
	<input class="form" type="text" name="price" onchange="validatePrice();" value="<?php echo $data["price"];?>"><br><p id="price"></p>
	Photo<br>
	<input id="image" type="file" name="image" value="<?php echo $data["image"];?>"disabled><br><br><p id="image"></p>
	<div class="float_right">
	<input class="button" id="submit" type="submit" value="CONFIRM" disabled>
	<input class="button" type="button" value="CANCEL">
	</div>
	</form>

	</body>

</html>