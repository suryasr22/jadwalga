<?php
	include "koneksi.php";
	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);
	move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
	$img_name = basename($_FILES["image"]["name"]);
	$tanggal = date("Y-m-d",time());
	$waktu = date("H:i:s",time());
	mysql_query("insert into product(id_user,name,description,price,image,date_now,time_now) values ('$_GET[active_id]','$_POST[name]','$_POST[desc]','$_POST[price]', '$img_name', '$tanggal', '$waktu')");

	header ("location:your_products.php?active_id=" . $_GET["active_id"]);
?>