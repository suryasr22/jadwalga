<?php
include "koneksi.php";
include "get_username.php";

$id_product = $_GET['id_product'];
$id_user = $_GET['active_id'];

$query = mysql_query("select * from product where id_product='$id_product'");
$data = mysql_fetch_array($query);

$tanggal = date("Y-m-d",time());
$waktu = date("H:i:s",time());

$total = $_POST["quantity"]*$data["price"];

mysql_query("insert into purchase(id_buyer,id_seller,id_product,product_name,price,consignee,address,postal_code,phone_number,date_now,time_now,quantity,cc_number,cc_verif,total_price,image) values ('$id','$data[id_user]','$id_product','$data[name]','$data[price]','$_POST[consignee]','$_POST[address]','$_POST[postal_code]','$_POST[phone_number]','$tanggal','$waktu','$_POST[quantity]','$_POST[cc_number]','$_POST[cc_verif]','$total','$data[image]')");

mysql_query("update product set purchases=purchases+1 where id_product='$id_product'");
	
header ("location: purchases.php?active_id=" . $id_user);
?>
