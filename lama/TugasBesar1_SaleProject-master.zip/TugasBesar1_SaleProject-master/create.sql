create table users(
	id_user int not null auto_increment,
	fullname text not null,
	username varchar(12) not null,
	email text not null,
	password varchar(12) not null,
	address text not null,
	postal_code int(5) not null,
	phone_number varchar(12) not null,

	primary key(id_user)
);

create table product(
	id_product int not null auto_increment,
	id_user int not null,
	name text not null,
	description varchar(200) not null,
	price int not null,
	image text not null,
	likes int not null,
	purchases int not null,
	date_now date not null,
	time_now time not null,

	primary key(id_product),
	foreign key(id_user) references users(id_user)
);

create table purchase(
	id_purchase int not null auto_increment,
	id_buyer int not null,
	id_seller int not null,
	id_product int not null,
	product_name text not null,
	price int not null,
	consignee text not null,
	address text not null,
	postal_code int(5) not null,
	phone_number varchar(12) not null,
	date_now date not null,
	time_now time not null,
	quantity int not null,
	cc_number int(12) not null,
	cc_verif int(3) not null,
	total_price int not null,
	image text not null,

	primary key(id_purchase),
	foreign key(id_product) references product(id_product),
	foreign key(id_buyer) references users(id_user)
);

create table likes(
	id_like int not null auto_increment,
	id_product int not null,
	id_liker int not null,

	primary key(id_like),
	foreign key(id_product) references product(id_product),
	foreign key(id_liker) references users(id_user)
);