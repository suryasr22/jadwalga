<!doctype html>
<html>
<head>
<title>Register</title>
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<script src = "functions.js"></script>

<body>
	<h2><font color='maroon'>Sale</font><font color='blue'>Project</h2></font>

<h3>Please Register</h3> 
<hr></hr>
	
<form name="register" action="proses_register.php" oninput="validateForm();" method="post">
Full Name
<br>
<input class="form" type="text" name="fullname" onfocusout="validateFName();"><p class="notice" id="fullname"></p>

Username
<br> 
<input class="form" type="text" name="username" onfocusout="validateUName();"><p class="notice" id="username"></p>

Email
<br>
<input class="form" type="text" name="email" onfocusout="validateEmail();"><p class="notice" id="email"></p>

Password
<br> 
<input class="form" type="password" name="password" onfocusout="validatePassword();"><p class="notice" id="password"></p>

Confirm Password
<br>
<input class="form" type="password" name="confirmpassword" onfocusout="confirmPassword();"><p class="notice" id="confirmpassword"></p>

Full Address
<br>
<textarea class="form" type="text" name="address" onfocusout="validateAddress();"></textarea><p class="notice" id="address"></p>

Postal Code
<br>
<input class="form" type="text" name="postal_code" onfocusout="validatePostal();"><p class="notice" id="postal_code"></p>

Phone Number
<br>
<input class="form" type="text" name="phone_number" onfocusout="validatePhone();"><p class="notice" id="phone_number"></p>

<div class="float_right">
<input class="button" id="submit" type="submit" name="submit" value="Register" disabled>
</div>
<br></br>
<br>
</form>
<div class="bold">All ready registered? Login<a class="here" href="index.php"> here </a></div>
</body>
</html>