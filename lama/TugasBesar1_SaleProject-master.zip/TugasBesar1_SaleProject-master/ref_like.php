<?php
	include "koneksi.php";

	$id_product = $_POST["id_product"];
	$state = $_POST["state"];

	$query = mysql_query("select likes from product where id_product='$id_product'");
	$result = mysql_result($query,0);
	
	if($state==1){
		echo ($result+1) . " likes<br>";
	}
	else{
		echo ($result-1) . " likes<br>";
	}
?>