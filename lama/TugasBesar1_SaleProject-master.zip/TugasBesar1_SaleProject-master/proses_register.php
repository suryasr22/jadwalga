<?php
include "koneksi.php";

$cek_username=mysql_num_rows(mysql_query
             ("SELECT username FROM users 
               WHERE username='$_POST[username]'"));
$cek_email=mysql_num_rows(mysql_query
             ("SELECT username FROM users 
               WHERE email='$_POST[email]'"));
if ($cek_username > 0 ||$cek_email > 0 ){
  echo "<script> alert('Username atau email Sudah ada');
			location='register.php';
			</script>";		
}
else{
mysql_query("insert into users(fullname,username,email,password,address,postal_code,phone_number)
  values ('$_POST[fullname]', '$_POST[username]', '$_POST[email]', '$_POST[password]', '$_POST[address]', '$_POST[postal_code]',
    '$_POST[phone_number]')");
}

$query = mysql_query("select * from users where username='$_POST[username]' and password='$_POST[password]'");
$row = mysql_fetch_array($query);

header ("location:catalog.php?active_id=" . $row["id_user"]);

?>