<!doctype html>
	<?php
		include "get_username.php";
		$id_product = $_GET['id_product'];
		$id_user = $_GET['active_id'];

		$query1 = "select * from users where id_user='$id_user'";
		$query2 = "select * from product where id_product='$id_product'";
		$perintah1 = mysql_query($query1);
		$perintah2 = mysql_query($query2);
		$data1=mysql_fetch_array($perintah1);
		$data2=mysql_fetch_array($perintah2);
	?>
<html>
	<head>
	<title>SaleProject</title>
	<script src = "functions.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	<body>
	<h2><font color='maroon'>Sale</font><font color='blue'>Project</h2></font>
	<div class="account">
	Hi, <?php echo $username?>!
	<br><a class="logout" href="index.php">logout</a>
	</div>

	<ul>
		<li><a href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li><a href="your_products.php?active_id=<?php echo $id; ?>">Your Products</a></li>
		<li><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li><a href="">Sales</a></li>
		<li><a href="">Purchases</a></li>
	</ul>
	<h3>Please confirm your purchase</h3><hr>

	<form oninput="validatePurchase();" action="proses_purchase.php?active_id=<?php echo $id;?>&id_product=<?php echo $id_product;?>" name="confirm" method="post">
	<table border="0">
	<tr>
		<td>Product</td>
		<td>:</td>
		<td><?php echo $data2['name'];?></td>
	</tr>
	<tr>
		<td>Price</td>
		<td>:</td>
		<td>IDR <?php echo $data2['price'];?></td>
	</tr>
	<tr>
		<td>Quantity</td>
		<td>:</td>
		<td>
			<input type="text" name="quantity" oninput="countTotal(this.value,<?php echo $data2['price'];?>);" onfocusout="validateQty();">pcs
		</td>
	</tr>
	<tr>
		<td>Total Price</td>
		<td>:</td>
		<td id="total">IDR 0</td>
	</tr>
	<tr>
		<td>Delivery to</td>
		<td>:</td>
		<td></td>
	</tr>
	<tr>
		<td></td>
	</tr>
	</table>

		Consignee
		<input class="form" type="text" name="consignee" onfocusout="validateCons();" value="<?php echo $data1['fullname'];?>"><p class="notice" id="consignee"></p>
		Full Address
		<textarea class="form" name="address" onfocusout="validateAddr();"><?php echo $data1['address'];?></textarea><p class="notice" id="address"></p>
		Postal Code
		<input class="form" type="text" name="postal_code" onfocusout="validatePostC();" value="<?php echo $data1['postal_code'];?>"><p class="notice" id="postal_code"></p>
		Phone Number
		<input class="form" type="text" name="phone_number" onfocusout="validatePhn();" value="<?php echo $data1['phone_number']?>"><p class="notice" id="phone_number"></p>
		16 Digit Credit Card Number
		<input class="form" type="text" onfocusout="validate16();" name="cc_number"><p class="notice" id="cc_number"></p>
		3 Digit Card Verification Value
		<input class="form" type="text" onfocusout="validate3();" name="cc_verif"><p class="notice" id="cc_verif"></p>
		<div class="float_right">
		<input class="button" id="submit" type="submit" value="CONFIRM" disabled>
		<input class="button" type="button" value="CANCEL">
		</div>
	</form>
	</body>
<html>