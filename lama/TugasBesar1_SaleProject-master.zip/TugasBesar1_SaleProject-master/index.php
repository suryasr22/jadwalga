<html>
	<head><title>Login</title></head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<body class="login">
	
	<h1><font color='maroon'>Sale</font><font color='#3d87ff'>Project</h1></font>
	<h3>Please login</h3><hr>

	<form action="cek_login.php" method="post">
	Email or Username<br>
	<input class="form" type="text" name="username"><br><br>

	Password<br>
	<input class="form" type="password" name="password"><br><br>

	<div class="float_right"><input class="button" type="submit" name="submit" value="LOGIN"><br></div>
	<br>
	<br>
	<br>
	<div class="bold">
	<h4>Don't have an account yet? Register 
	<a class="here" href="register.php">here</a></h4>
	</div>
	</form>
	</body>
</html>