<!doctype html>
	<?php
		include "get_username.php";
	?>
<html>
	<head>
	<title>SaleProject</title>
	</head>
	<script src = "register.js"></script>
	<body>


	<h2>SaleProject</h2>
	Hi, <?php echo $username?>!
	<br><a href="index.php">logout</a>
	<ul class="sub">
		<li class="sub"><a href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li class="sub"><a href="your_products.php?active_id=<?php echo $id; ?>">Your Products</a></li>
		<li class="sub"><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li class="sub"><a class="active" href="">Sales</a></li>
		<li class="sub"><a href="purchase.php?active_id=<?php echo $id; ?>">Purchases</a></li>
	</ul>
<Left><H2>Here are your sales </h2></Left> 
<hr></hr>
<br>
<?php
		$query="select * from product,purchase where product.id_product=purchase.id_product ";
		$perintah=mysql_query($query);
				
		while ($data=mysql_fetch_array($perintah))
		{?>
		<?php 
echo $data['date_now']."<br>at ";
echo $data['time_now']."<br>";
?>

<hr></hr>
		<img src="uploads/<?php echo $data['image']; ?>" width="100" height="100"><br>
		<?php
			echo $data['name'] . "<br>IDR ";
			echo $data['price'] . "<br>";
			echo $data['quantity']."pcs<br>";
			echo $data['total_price']."<br>bougt by ";
			echo $data['consignee']."<br>";
			echo $data['address']."<br>";
			echo $data['postal_code']."<br>";
			echo $data['phone_number']."<br>";
			echo "<br>";
			echo "<br>";
			}
		
?>

<br></br>
</table>
</form>
</body>