<!doctype html>
	<?php
		include "get_username.php";
	?>
<html>
	<head>
	<title>SaleProject</title>
	<script src = "functions.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	<body>
	<h2><font color='maroon'>Sale</font><font color='blue'>Project</h2></font>
	<div class="account">
	Hi, <?php echo $username?>!
	<br><a class="logout" href="index.php">logout</a>
	</div>

	<ul>
		<li><a href="catalog.php?active_id=<?php echo $id; ?>">Catalog</a></li>
		<li><a class="active">Your Products</a></li>
		<li><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li><a href="sales.php?active_id=<?php echo $id; ?>">Sales</a></li>
		<li><a href="purchases.php?active_id=<?php echo $id; ?>">Purchases</a></li>
	</ul>
	<h3>What are you going to sell today?</h3><hr>

	<div id="page">
	<?php

		$query="select * from product,users where users.id_user=product.id_user and users.id_user='$id'";
		$perintah=mysql_query($query);

		if(mysql_num_rows($perintah) > 0){
			while ($data=mysql_fetch_array($perintah)){
				?>
				
				<div class="bold"><?php echo $data['username'];?></div>
				
				<?php
					echo "added this on " . $data['date_now'] . ", ";
					echo "at " . $data['time_now'] . "<hr>";
				?>
				<div class="product">
					<img src="uploads/<?php echo $data['image']; ?>" width="100" height="100">

					<div class="details">
						<div class="bold"><?php echo $data['name'] . "<br>";?></div>
						<div class="price"><?php echo "IDR " . $data['price'] . "<br>"; ?></div>
						<?php echo $data['description'] . "<br>"; ?>
					</div>

					<div class="like">
					<div id="like<?php echo $data['id_product'];?>"><?php echo $data['likes'] . " likes<br>";?></div>
					<?php
						echo $data['purchases'] . " purchases<br>";
						echo "<br>";
					?>
					<a href="edit_product.php?active_id=<?php echo $id;?>&id_product=<?php echo $data["id_product"];?>"><input class="edit" type="button" value="EDIT"></a>
					<a href="delete.php?active_id=<?php echo $id;?>&id_product=<?php echo $data["id_product"];?>"><input class="delete" type="button" value="DELETE"></a><br>
					</div>
				</div>
				<hr>
				<br><br>
				<?php
			}
		}
		else{
			echo "You haven't added any product yet!";
		}
	?>
	</div>
	</body>
</html>