<!doctype html>
	<?php
		include "get_username.php";
	?>
<html>
	<head>
	<title>SaleProject</title>
	<script src = "functions.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	<body>
	<h2><font color='maroon'>Sale</font><font color='#3d87ff'>Project</h2></font>
	<div class="account">
	Hi, <?php echo $username?>!
	<br><a class="logout" href="index.php">logout</a>
	</div>

	<ul>
		<li><a class="active">Catalog</a></li>
		<li><a href="your_products.php?active_id=<?php echo $id; ?>">Your Products</a></li>
		<li><a href="add_product.php?active_id=<?php echo $id; ?>">Add Product</a></li>
		<li><a href="sales.php?active_id=<?php echo $id; ?>">Sales</a></li>
		<li><a href="purchases.php?active_id=<?php echo $id; ?>">Purchases</a></li>
	</ul>
	<h3>What are you going to buy today?</h3><hr>

	<div class="radio">
	<form action="catalog.php?active_id=<?php echo $id; ?>" method="post">
		<input class="search" id="search" type="text" name="search" placeholder="Search catalog ...">
		<input class="button" name="submit" type="submit" value="GO"><br>
		<table>
		<tr>
			<th>by:</th>
			<th><input type="radio" name="category" value="product" checked>product<br></th>
		</tr>
		<tr>
			<th></th>
			<th><input type="radio" name="category" value="users">store
			</th>
		</tr>
		</table>
	</form>
	</div>
	<br>

	<div id="page">
	<?php

		$query="select * from product,users where users.id_user=product.id_user";
		$perintah=mysql_query($query);

		if(isset($_POST["search"])&&isset($_POST["category"])){
			if($_POST["search"]=="" || $_POST["search"]==null){
				$query="select * from product,users where users.id_user=product.id_user";
			}
			else{
				if($_POST["category"] == "product"){
					$product = $_POST["search"];
					$query="select * from product,users where users.id_user=product.id_user and product.name like '%$product%'";
				}
				else if($_POST["category"] == "users"){
					$username = $_POST["search"];
					$query="select * from product,users where users.id_user=product.id_user and users.username like '%$username%'";
				}
				if(mysql_num_rows(mysql_query($query)) == 0){
					$query="select * from product,users where users.id_user=product.id_user";
					echo "Pencarian tidak ditemukan<br>";
				}
			}
		}

		$perintah=mysql_query($query);
		while ($data=mysql_fetch_array($perintah)){
			?>
			
			<div class="bold"><?php echo $data['username'];?></div>

			<?php
				echo "added this on " . $data['date_now'];
				echo ", at " . $data['time_now'] . "<hr>";
			?>
			<div class="product">
				<img src="uploads/<?php echo $data['image']; ?>" width="100" height="100">

				<div class="details">
					<div class="bold"><?php echo $data['name'] . "<br>";?></div>
					<div class="price"><?php echo "IDR " . $data['price'] . "<br>"; ?></div>
					<?php echo $data['description'] . "<br>"; ?>
				</div>

				<div class="like">
				<div id="like<?php echo $data['id_product'];?>"><?php echo $data['likes'] . " likes<br>";?></div>
				<?php
					echo $data['purchases'] . " purchases<br>";
					echo "<br>";
				?>
				<input class="like" id="<?php echo $data['id_product'];?>" type="button" onclick="like(<?php echo $data['id_product'] . "," . $id;?>,'add_like.php'); addLike(<?php echo $data['id_product'];?>);" value="LIKE">
				<a href="confirm_purchase.php?active_id=<?php echo $id;?>&id_product=<?php echo $data["id_product"];?>"><input class="buy" type="button" value="BUY"><br></a>
				</div>
				<script>window.onload = like(<?php echo $data['id_product'] . "," . $id;?>,"is_like.php");</script>
			</div>
			<hr>
			<br><br>
			<?php
		}
	?>
	</div>
	</body>
</html>